-- Inserção de dados de exemplo (DML)
INSERT INTO Cliente (nome, tipo_cliente, cpf_cnpj, email, telefone)
VALUES ('João Silva', 'PF', '123.456.789-00', 'joao@email.com', '(11)99999-0000');