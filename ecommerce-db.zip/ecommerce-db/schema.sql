-- Script SQL de criação do esquema do banco de dados (DDL)
CREATE TABLE Cliente (
    id_cliente SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    tipo_cliente CHAR(2) CHECK (tipo_cliente IN ('PF','PJ')),
    cpf_cnpj VARCHAR(18) UNIQUE NOT NULL,
    email VARCHAR(120),
    telefone VARCHAR(20)
);