# 🛒 Projeto de Banco de Dados - E-commerce
## 📘 Descrição do Projeto
Este projeto apresenta o **modelo lógico e físico** de um banco de dados para um **sistema de e-commerce**, desenvolvido como parte de um desafio prático de modelagem de dados.
...